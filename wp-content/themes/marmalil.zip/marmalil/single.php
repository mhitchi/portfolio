<?php
/**
 * 
 * Single post template
 * 
 * @package marmalil
 */

 get_header();
?>
 <div>Single Post</div>

 <?php get_footer() ?>