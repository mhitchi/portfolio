<?php
/**
 * 
 * Standard page template
 * 
 * @package marmalil
 */

 get_header();
?>
 <div>Standard Page</div>

 <?php get_footer() ?>