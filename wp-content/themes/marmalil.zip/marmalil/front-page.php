<?php
/**
 * 
 * Front page template
 * 
 * @package marmalil
 */

 get_header();
?>
 <div>Front Page</div>

 <?php get_footer() ?>