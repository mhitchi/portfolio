<?php

/**
 * 
 * Template for entry meta
 * 
 * @package Marmalil
 * 
 */
?>

<div class="entry-meta mb-3">

</div>