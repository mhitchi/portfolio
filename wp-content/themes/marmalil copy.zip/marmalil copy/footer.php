<?php
/**
 * Theme Footer Template - Marmalil
 * 
 * @package Marmalil
 */
?>

<p>Footer</p>
<!-- add logo for home and links to design and development -->
<!-- add logo for home and links to github, linkedin, email btn-->
<?php wp_footer(); ?>
</body>
</html>