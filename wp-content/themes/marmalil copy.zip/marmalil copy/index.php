<?php
/**
 * Main template file
 * 
 * @package Marmalil
 */

        get_header();
    ?>
    <div class="page-content">
    </div>
    <?php 
        get_footer();
